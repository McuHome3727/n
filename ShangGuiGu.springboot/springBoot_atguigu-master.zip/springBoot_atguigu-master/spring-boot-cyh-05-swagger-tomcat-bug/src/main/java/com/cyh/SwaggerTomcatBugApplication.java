package com.cyh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwaggerTomcatBugApplication {

    public static void main(String[] args) {
        SpringApplication.run(SwaggerTomcatBugApplication.class, args);
    }

}
