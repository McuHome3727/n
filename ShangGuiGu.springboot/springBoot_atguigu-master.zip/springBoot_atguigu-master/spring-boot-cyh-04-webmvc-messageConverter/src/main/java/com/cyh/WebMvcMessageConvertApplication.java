package com.cyh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author: yanhua.chen
 * @date: 2019/5/14 11:44
 */
@SpringBootApplication
public class WebMvcMessageConvertApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebMvcMessageConvertApplication.class, args);
    }

}
