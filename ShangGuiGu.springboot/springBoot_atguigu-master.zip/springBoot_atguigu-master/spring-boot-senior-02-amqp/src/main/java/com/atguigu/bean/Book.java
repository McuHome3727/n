package com.atguigu.bean;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author: CYH
 * @date: 2018/11/6 0006 8:26
 */
@Data
@AllArgsConstructor
public class Book {

    private String bookName;
    private String author;

}
